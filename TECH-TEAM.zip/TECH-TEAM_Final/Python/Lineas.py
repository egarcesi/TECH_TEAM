import pandas as pd
import matplotlib.pyplot as plt

# Cargar los datos desde el archivo CSV
file_path = r"C:/Users/egi20\Desktop/TECH_TEAM/Python/Consumo.csv"  
data = pd.read_csv(file_path)

# Crear el gráfico de líneas
plt.figure(figsize=(10, 6))

# Graficar cada fuente de energía
plt.plot(data['Year'], data['Eolica'], label='Eólica', marker='o', linestyle='-')
plt.plot(data['Year'], data['Hidroelectrica'], label='Hidroelectrica', marker='o', linestyle='-')
plt.plot(data['Year'], data['Solar '], label='Solar', marker='o', linestyle='-')
plt.plot(data['Year'], data['Otras'], label='Otras', marker='o', linestyle='-')

# Personalizar el gráfico
plt.title('Tendencia de la Capacidad Instalada de Energías Renovables en Colombia', fontsize=14)
plt.xlabel('Año', fontsize=12)
plt.ylabel('Capacidad (TWh)', fontsize=12)
plt.legend(title='Fuentes de Energía', fontsize=10)
plt.grid(alpha=0.3)

# Guardar el gráfico como archivo PNG
output_path = r"C:/Users/egi20/Desktop/TECH_TEAM/Python/Tendencia_Energias.png"
plt.savefig(output_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"Gráfico guardado en: {output_path}")
