import pandas as pd
import matplotlib.pyplot as plt

# Cargar los datos desde el archivo CSV
file_path = r"C:/Users/egi20\Desktop/TECH_TEAM/Python/Produccion.csv"  
data = pd.read_csv(file_path)

# Configurar el gráfico de barras apiladas
fig, ax = plt.subplots(figsize=(10, 6))

# Establecer las fuentes de energía
fuentes = ["Eolica", "Hidroelectrica", "Solar", "Otras"]

# Apilar las barras para cada fuente
for fuente in fuentes:
    ax.bar(
        data["Year"],
        data[fuente],
        bottom=data[fuentes].iloc[:, :fuentes.index(fuente)].sum(axis=1),
        label=fuente,
    )

# Configurar etiquetas y título
ax.set_title("Producción de Energía Renovable por Año", fontsize=16)
ax.set_xlabel("Año", fontsize=12)
ax.set_ylabel("Producción (TWh)", fontsize=12)
ax.legend(title="Fuente de Energía")


# Guardar el gráfico como archivo PNG
output_path = r"C:/Users/egi20/Desktop/TECH_TEAM/Python/Barras_Energias.png"
plt.savefig(output_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"Gráfico guardado en: {output_path}")
